<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<?php $user=Session::get('user'); 
	if($user != "")
	{
		echo "Welcome ".$user;
		?>
		<?php
	}
	else
	{
		echo "not found";
	}
	?>

</center>
</body>
</html>