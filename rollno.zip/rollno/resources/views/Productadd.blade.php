<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<center>
	<form action="/insert">
		<h1>Add Product</h1>
		Product Name<input type="text" name="pn"><br>
		Product Price<input type="text" name="pp"><br>
		Product Description<input type="text" name="pd"><br>
		
		<input type="submit" name="submit" value="submit">
	</form>
	</center>
</body>
</html>