<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<h1>Product</h1>
	<table border="1">
		<tr>
			<td>ID</td>
			<td>Product Name</td>
			<td>Product Price</td>
			<td>Product Description</td>
			
		</tr>
		
		@foreach($tabledata as $data)
		<tr>
			<td>{{$data->id}}</td>
			<td>{{$data->Productname}}</td>
			<td>{{$data->Productprice}}</td>
			<td>{{$data->Productdesc}}</td>
			<td><a href='/prdhome?pn={{$data->Productname}}'>Add to cart</a></td>
			
		</tr>
		@endforeach
	</table>
</center>
</body>
</html>