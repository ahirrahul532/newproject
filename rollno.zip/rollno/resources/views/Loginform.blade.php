<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		<center>
			<form action="/logindb">
				<h1>Login Form</h1>
				Customer Name:<input type="text" name="sn"><br>
				Customer Password:<input type="text" name="sp"><br>
				<input type="submit" name="submit" value="submit">
			</form>
		</center>
</body>
</html>