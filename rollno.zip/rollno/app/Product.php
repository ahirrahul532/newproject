<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Http\Request;
class Product extends Model
{
    public static function insertdata(Request $request)
    {
    	$sn=$request->input('sn');
    	$sp=$request->input('sp');
    	$sm=$request->input('sm');
    	$scn=$request->input('scn');
    	$sc=$request->input('sc');
    	$data=array('Username'=>$sn, 'Password'=>$sp, 'Email'=>$sm, 'Contactno'=>$scn, 'Cource'=>$sc);
    	DB::table('Studentreg')->insert($data);
    	// echo "Insert Successfully";
    	
    	// echo "<a href ='/stdlogin'>Login</a>";
    }	
    public static function logindata(Request $request)
    {
    	$sn=$request->input('sn');
    	$sp=$request->input('sp');
    	$data=DB::select('select * from Studentreg where Username = ? and Password = ?',[$sn,$sp]);
}
