<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Http\Request;
class Student extends Model
{
    public static function insertdata(Request $request)
    {
    	$sn=$request->input('sn');
    	$sp=$request->input('sp');
    	$sm=$request->input('sm');
    	$scn=$request->input('scn');
    	
    	$data=array('Username'=>$sn, 'Password'=>$sp, 'Email'=>$sm, 'Contactno'=>$scn);
    	DB::table('Customer')->insert($data);
    	// echo "Insert Successfully";
    	
    	// echo "<a href ='/stdlogin'>Login</a>";
    }	
    public static function logindata(Request $request)
    {
    	$sn=$request->input('sn');
    	$sp=$request->input('sp');
    	$data=DB::select('select * from Customer where Username = ? and Password = ?',[$sn,$sp]);
        // return $data;
        // $request->session()->put('user',$request->input('sn'));

        
        if ($data==True) {
            echo "<a href ='/prd'>ADD Products</a>";
           
        }
        else
        {
            echo "<a href ='/reg'>Register first</a>";
        }
    }
    public static function insertprg(Request $request)
    {
        $pn=$request->input('pn');
        $pp=$request->input('pp');
        $pd=$request->input('pd');
        
        $data=array('Productname'=>$pn,'Productprice'=>$pp,'Productdesc'=>$pd);
        DB::table('Product')->insert($data);
        echo "Insert Successfully";
        echo "Click to Display Prodcut";
        echo "<a href ='/display'>Display</a>";
    }
    public static function selectdata()
    {
        $tabledata=DB::table('Product')->get();
        return $tabledata;
    }

}
    