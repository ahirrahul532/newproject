<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;

class StudentRegistration extends Controller
{
    public function new()
    {
        return view('homepage');
    }
    public function index()
    {
    	return view('Regform');
    }
    public function insert(Request $request)
    {
    	Student::insertdata($request);
    	// $request->session()->put('user',$request->input('sn'));
    	// echo "Welcome " .$request->session()->get('user');
        return view('Loginform');
    }
    public function student_login()
    {
    	return view('Loginform');

    }
    public function logincheck(Request $request)
    {
        Student::logindata($request); 
    	// $uname=Student::logindata($request);
     //    if($uname)
     //    {
     //        $request->session()->put('user',$request->input('sn'));
     //    }
     //    return view('Studenthome');
        // return view('Productadd');
    }
    public function home()
    {
        return view('Productadd');
    }
    public function product(Request $request)
    {
        Student::insertprg($request);
        // $request->session()->put('prd',$request->input('pn'));
    }
    public function display()
    {
        $tabledata=Student::selectdata();
        return view('Productdisplay',['tabledata'=>$tabledata]);
    }
    public function session(Request $request)
    {
        $request->session()->put('prd',$request->input('pn'));
        return view('Producthome');
    }
}
