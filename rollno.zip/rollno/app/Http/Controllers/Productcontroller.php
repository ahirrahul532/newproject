<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;
class Productcontroller extends Controller
{
    public function new()
    {
        return view('homepage');
    }
    public function index()
    {
    	return view('Regform');
    }
    public function insert(Request $request)
    {
    	Student::insertdata($request);
        return view('Loginform');
    }
    public function student_login()
    {
    	return view('Loginform');

    }
    public function logincheck(Request $request)
    {
        Student::logindata($request); 
}
