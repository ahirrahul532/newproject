<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<h1>Welcome Laravel</h1>
	<table>
		<tr>
			<td><a href="/reg">Registration</a></td>
			<td><a href="/stdlogin">Login</a></td>
		</tr>
	</table>
</center>
</body>
</html><?php /**PATH C:\Users\Mohit\Desktop\rollno\resources\views/homepage.blade.php ENDPATH**/ ?>