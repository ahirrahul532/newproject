<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<?php $user=Session::get('user'); 
	if($user != "")
	{
		echo "Welcome ".$user;
		?>
		<?php
	}
	else
	{
		echo "again";
	}
	?>

</center>
</body>
</html><?php /**PATH C:\Users\Mohit\Desktop\rollno\resources\views/Studenthome.blade.php ENDPATH**/ ?>