<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<form action="/insertdb">
		<h1>Customer Registration</h1>
		Customer Name<input type="text" name="sn"><br>
		Customer Password<input type="text" name="sp"><br>
		Customer Email<input type="text" name="sm"><br>
		Customer Contact_no<input type="text" name="scn"><br>
		<!-- Customer Course<input type="text" name="sc"><br> -->
		<input type="submit" name="submit" value="submit">
	</form>
</center>
</body>
</html><?php /**PATH C:\Users\Mohit\Desktop\rollno\resources\views/Regform.blade.php ENDPATH**/ ?>