<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<h1>Product</h1>
	<table border="1">
		<tr>
			<td>ID</td>
			<td>Product Name</td>
			<td>Product Price</td>
			<td>Product Description</td>
			
		</tr>
		
		<?php $__currentLoopData = $tabledata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($data->id); ?></td>
			<td><?php echo e($data->Productname); ?></td>
			<td><?php echo e($data->Productprice); ?></td>
			<td><?php echo e($data->Productdesc); ?></td>
			<td><a href='/prdhome?pn=<?php echo e($data->Productname); ?>'>Add to cart</a></td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</center>
</body>
</html><?php /**PATH C:\Users\Mohit\Desktop\rollno\resources\views/Productdisplay.blade.php ENDPATH**/ ?>