<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<?php $prd=Session::get('prd'); 
	if($prd != "")
	{
		echo "Welcome ".$prd;
		?>
		<?php
	}
	else
	{
		echo "not found";
	}
	?>

</center>
</body>
</html><?php /**PATH C:\Users\Mohit\Desktop\rollno\resources\views/Producthome.blade.php ENDPATH**/ ?>